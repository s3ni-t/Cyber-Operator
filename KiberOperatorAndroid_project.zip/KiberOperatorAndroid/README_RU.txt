КИБЕРОПЕРАТОР 1.7.3 — Android-проект

Что внутри:
- HTML-игра в app/src/main/assets/index.html
- Android WebView-оболочка
- JavaScript и DOM storage включены, чтобы локальные аккаунты/прогресс могли сохраняться
- Сеть не требуется для текущего HTML-файла

Как собрать APK:
1. Установите Android Studio на компьютер.
2. Откройте в Android Studio папку KiberOperatorAndroid.
3. Дождитесь синхронизации Gradle и установки необходимых компонентов Android SDK.
4. Выберите Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK будет в app/build/outputs/apk/debug/app-debug.apk.

Если Android Studio попросит установить Android SDK Platform 35 и Android Gradle Plugin, согласитесь.
Это исходный Android-проект, а не уже собранный APK. Для сборки нужен Android SDK/Gradle.
